import assemblyai as aai
import os
import time
import requests

# 配置API密钥和美国端点
aai.settings.api_key = "3614a1c310e545fd819392dd93e3624b"
aai.settings.base_url = "https://api.assemblyai.com"


def upload_audio_file(file_path):
    """上传本地音频文件"""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"音频文件不存在: {file_path}")

    with open(file_path, "rb") as f:
        headers = {
            "authorization": aai.settings.api_key,
            "content-type": "application/octet-stream"
        }

        print(f"正在上传音频文件: {file_path}")
        response = requests.post(
            f"{aai.settings.base_url}/v2/upload",
            headers=headers,
            data=f,
            timeout=30
        )

        if response.status_code != 200:
            raise RuntimeError(f"文件上传失败: {response.text}")

        return response.json()["upload_url"]


def transcribe_audio(audio_url):
    """转录音频并启用说话人分离（适配旧版本SDK）"""
    # 仅使用speaker_labels参数，移除speakers（旧版本不支持）
    config = aai.TranscriptionConfig(
        language_code="en",
        speaker_labels=True  # 仅启用说话人分离，不指定数量
    )

    print("提交转录请求（含人声分离）...")
    transcriber = aai.Transcriber(config=config)
    transcript = transcriber.transcribe(audio_url)

    # 获取转录ID用于进度查询
    transcript_id = transcript.id
    polling_url = f"{aai.settings.base_url}/v2/transcript/{transcript_id}"
    headers = {"authorization": aai.settings.api_key}

    # 检查初始状态
    status_response = requests.get(polling_url, headers=headers, timeout=10)
    status_data = status_response.json()

    # 显示进度
    if status_data.get("status") not in ["completed", "failed"]:
        print("开始转录（含人声分离），正在处理...")

        while True:
            status_response = requests.get(polling_url, headers=headers, timeout=10)
            status_data = status_response.json()

            if status_data.get("status") == "completed":
                return transcriber.transcribe(audio_url)
            elif status_data.get("status") == "failed":
                raise RuntimeError(f"转录失败: {status_data.get('error', '未知错误')}")

            # 显示进度
            if "audio_duration" in status_data and "processed_seconds" in status_data:
                total = status_data["audio_duration"]
                processed = status_data["processed_seconds"]
                progress = min(int((processed / total) * 100), 100)
                print(f"\r转录进度: {progress}% ({processed:.1f}/{total:.1f}秒)", end="")

            time.sleep(2)

    return transcript


def save_transcript_result(transcript, output_file="transcription_result.txt"):
    """保存转录结果（含人声分离信息）"""
    if not transcript or not transcript.text:
        print("没有可保存的转录结果")
        return

    try:
        with open(output_file, "w", encoding="utf-8") as f:
            f.write("=== 完整转录文本 ===\n\n")
            f.write(transcript.text + "\n\n")

            # 保存人声分离结果（增加容错检查）
            speaker_info_saved = False
            if hasattr(transcript, 'utterances') and transcript.utterances:
                f.write("=== 人声分离结果（说话人识别） ===\n")
                for utterance in transcript.utterances:
                    if hasattr(utterance, 'speaker'):
                        f.write(f"说话人 {utterance.speaker}: {utterance.text}\n")
                        speaker_info_saved = True

            # 如果没有保存到说话人信息，说明功能未启用或不支持
            if not speaker_info_saved:
                f.write("=== 人声分离结果 ===\n")
                f.write("未获取到说话人信息（可能是SDK版本不支持该功能）\n")

        print(f"\n转录结果已保存至: {output_file}")
        print(f"文本长度: {len(transcript.text)}字符")

    except Exception as e:
        print(f"保存结果出错: {str(e)}")


if __name__ == "__main__":
    local_audio_file = "test_audio4.mp3"
    absolute_path = os.path.abspath(local_audio_file)
    print(f"本地文件路径: {absolute_path}")

    try:
        audio_url = upload_audio_file(absolute_path)
        result = transcribe_audio(audio_url)

        if result.status == "error":
            raise RuntimeError(f"转录失败: {result.error}")

        print("\n转录成功!")
        save_transcript_result(result)

        print("\n转录文本预览:")
        preview = result.text[:500].replace("\n", " ")
        print(preview + ("..." if len(result.text) > 500 else ""))

    except Exception as e:
        print(f"\n处理过程出错: {str(e)}")
